<?php
return [
    'userGroup' => 'O:36:"common\\components\\rbac\\UserGroupRule":3:{s:4:"name";s:9:"userGroup";s:9:"createdAt";N;s:9:"updatedAt";N;}',
    'inSite' => 'O:31:"common\\components\\rbac\\SiteRule":3:{s:4:"name";s:6:"inSite";s:9:"createdAt";N;s:9:"updatedAt";N;}',
];
